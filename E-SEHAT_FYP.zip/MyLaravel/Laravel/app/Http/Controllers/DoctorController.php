<?php


namespace App\Http\Controllers;
use App\Contact;
use App\Doctor;
use App\Profile;
use App\Booking;
use Illuminate\Http\Request;
//use Intervention\Image\Facades\Image;
use Image;
use Storage;
use DB;
use Session;
use Illuminate\Validation\Rule;
//use Intervention\Image\ImageManagerStatic as Image;
use Validator;



class DoctorController extends Controller
{
    //
    public function menu()
    {
        return view('E-SEHAT.doctormenu');
    }
    public function contact()
    {
        return view('E-SEHAT.doctorcontact');
    }
    public function contactInfo(Request $request)
    {
        $v = Validator::make($request->all(), [
            'email' => 'required',
            'name' => 'required',
            'phone'=> 'required|min:11|max:11',
            'message' => 'required',
            
        ]);
    
        if ($v->fails())
        {
          
            return redirect()->back()->withErrors($v->errors());
          
        }
        else
        {
            $contact=new Contact();
            $contact->name=request('name');
            $contact->email=request('email');
            $contact->phone=request('phone');
            $contact->message=request('message');
            $created=$contact->save();
            if($created)
            {
            return redirect('E-SEHAT/contact');
            }
           
        }
    }
    
    
    public function uploadFile($file){
        $extension = $file->getClientOriginalExtension();
        $fileName = time().'.'.$extension;
        $path = public_path().'\Uploadfiles';
        $upload = $file->move($path,$fileName);
        return $fileName;
     }
    public function getLogout(){
        Auth::logout();
        Session::flush();
        return redirect('E-SEHAT/menu');
    }

    public function docProfile()
    {
        return view('E-SEHAT.doctorProfile');
    }
    public function doctorLogin()
    {
        return view('E-SEHAT.doctorLogin');
    }
    public function doctorlog(Request $request)
    {       
                
        $v = Validator::make($request->all(), [
            'email' => 'required',
            'name' => 'required',
            'phone'=> 'required|min:11|max:11',
            'password'=>'required|min:6|max:6',
            'speciality'=>'required',
            'city' => 'required',
            'designation' => 'required',
            'pmdc' => 'required',
            'message'=>'required',
            'file' =>'required|mimes:doc,docx,pdf'
        ]);
    
        if ($v->fails())
        {  
            return redirect()->back()->withErrors($v->errors()); 
        }
        else
            {
                $sehat=new Doctor();
                $sehat->name=request('name');
                $sehat->email=request('email');
                $sehat->phone=request('phone');
                $sehat->password=request('password');
                $sehat->city=request('city');
                $sehat->designation=request('designation');
                $sehat->speciality=request('speciality');
                $sehat->pmdc=request('pmdc');
                $sehat->message=request('message');
                $file = $request->file('file');
                //$a = $file->getClientOriginalName();
                //$b = base64_encode(file_get_contents($file->getRealPath()));
                // $d= $file->getRealPath();
                //$c = $file->getMimeType();
                $fileUploadName = $this->uploadFile($file);
                $sehat->file = $fileUploadName;
                $created=$sehat->save();
                if($created)
                {
                return redirect('E-SEHAT/doctorLogin')->with('success', 'You would be notiefied later by email..Just Keep in touch with us!! After receiving confirmation, You can login into our Account as a Doctor!');
                }
               
            }
    
        
    }


    public function profile(Request $request)
    {
        $v = Validator::make($request->all(), [
           /*'image' => 'required|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'about' => 'required',
            'qualification'=> 'required',
            'services'=>'required',
            'experience'=>'required',
            'yearNo' => 'required',
            'organization' => 'required',
            'location' => 'required',
            'city'=>'required',
            'days'=>'"required|array',
            'from' => 'required',
            'to' => 'required',
            'duration' => 'required',
            'fees'=>'required',
            'Vdays'=>'"required|array',
            'Vfrom' => 'required',
            'Vto' => 'required',
            'Vduration' => 'required',
            'Vfees'=>'required'*/
            
        ]);
    
        if ($v->fails())
        {  
            return redirect()->back()->withErrors($v->errors()); 
        }
        else
            {
                
                $expNo=request('yearNo');
                $expduration=request('years');
                $Exp_time=$expNo." ".$expduration;
                
                $from=date("h:i a", strtotime(request('from'))); 
                $to=date("h:i a", strtotime(request('to'))); 
                $clinic_duration=$from."-".$to;
    
                $Vfrom=date("h:i a", strtotime(request('Vfrom'))); 
                $Vto=date("h:i a", strtotime(request('Vto'))); 
                $video_duration= $Vfrom."-".$Vto;

                $Working_days =implode( ",",request('days') ); 
                $VWorking_days =implode( ",",request('Vdays') );  
                

                $sehat=new Profile();
                $sehat->id = Session::get('key');
                //$sehat->id = 1;
                $sehat->About=request('about');
                $sehat->Qualification=request('qualification');
                $sehat->Services=request('services');
                $sehat->Experience=request('experience');
                $sehat->Experience_Time=$Exp_time;
                $sehat->Organization=request('organization');
                $sehat->Location=request('location');
                $sehat->City=request('city');
                $sehat->Working_days=$Working_days ;
                $sehat->Time= $clinic_duration;
                $sehat->Duration=request('duration');
                $sehat->Fees=request('fees');
                $sehat->VWorking_days= $VWorking_days;
                $sehat->VTime=$video_duration;
                $sehat->VDuration=request('Vduration');
                $sehat->VFees=request('Vfees');
                $image = $request->file('image');
                $filename = time() . '.' . $image->getClientOriginalExtension();
                Image::make($image)->resize(300, 300)->save( storage_path('uploads' . $filename ) );
                $sehat->Image = $filename;
                $created=$sehat->save();
                if($created)
                {
                return redirect('E-SEHAT/doctorProfile')->with('success', 'Your Profile has been updated! Go to Profile Icon!');
                }
                //return redirect('E-SEHAT/doctorProfile')->with('success', 'You would be notiefied later by email..Just Keep in touch with us!! After receiving confirmation, You can login into our Account as a Doctor!');
               
            }
    
        
    }

    public function showProfile()
    {
        $i=0;
        $id = Session::get('key');
        $doctor=DB::select( 'select * from doctors inner join profiles on doctors.id=profiles.id');
        $myArray = json_decode(json_encode($doctor), true);
        //print_r($myArray);
        foreach($myArray as $x => $x_value) {
            if($myArray[$x]["id"] == $id){
                //print_r( "Key=" . $x );
                //echo "<br>";
                $id=$x;
                $i=1;
            }
            
          }
          
        if($i == 0)
        {
            return view('E-SEHAT.askprof');
        }  
        else{
            Session::put('days', $myArray[$id]['Working_days']);
            Session::put('vdays', $myArray[$id]['VWorking_days']);
            return view('E-SEHAT.profile',['doctor'=>$myArray[$id]]);
            
        }


    }
    public function edit()
    {
        $id = Session::get('key');
        $doctor=$datas=DB::select( 'select * from  profiles');
        $myArray = json_decode(json_encode($doctor), true);
        foreach($myArray as $x => $x_value) {
            if($myArray[$x]["id"] == $id){
                $id=$x;
            }
            
          }
        $eno=$myArray[$id]['Experience_Time'];
        $data=$myArray[$id]['Time'];
        $datas=$myArray[$id]['VTime'];
        $myArray[$id]['FExperience_Time']= strtok( $eno, ' ' );
        $myArray[$id]['Experience_Time']= substr($eno, strpos($eno, " ") + 1);
        $myArray[$id]['FTime']= strtok( $data, '-' );
        $myArray[$id]['Time']= substr($data, strpos($data, "-") + 1); 
        $myArray[$id]['FVTime']= strtok( $datas, '-' );
        $myArray[$id]['VTime']= substr($datas, strpos($datas, "-") + 1); 
        //print_r($myArray[$id]);
        return view('E-SEHAT.editprofile',['doctor'=>$myArray[$id]]);

    }

    public function update(Request $request)
    {
        $v = Validator::make($request->all(), [
            //'image' => 'required|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'about' => 'required',
            'qualification'=> 'required',
            'services'=>'required',
            'experience'=>'required',
            'yearNo' => 'required',
            'organization' => 'required',
            'location' => 'required',
            'city'=>'required',
            'from' => 'required',
            'to' => 'required',
            'duration' => 'required',
            'fees'=>'required',
            'Video_from' => 'required',
            'Video_to' => 'required',
            'Vduration' => 'required',
            'Vfees'=>'required'
            
        ]);
    
        if ($v->fails())
        {  
            return redirect()->back()->withErrors($v->errors()); 
        }
        else
            {
                
                $expNo=request('yearNo');
                $expduration=request('years');
                $Exp_time=$expNo." ".$expduration;
                
                $from=request('from'); 
                $to=request('to'); 
                $clinic_duration=$from."-".$to;
    
                $Vfrom=request('Video_from'); 
                $Vto=request('Video_to'); 
                $video_duration= $Vfrom."-".$Vto;

            
               $sehat=new Profile();
                
                $days=Session::get('days');;
                $vdays=Session::get('vdays');;
                $sehat->Working_days=$days;
                $sehat->VWorking_days=$vdays;

                if(request('days') != "")
                {
                    $Working_days =implode( ",",request('days') ); 
                    $sehat->Working_days=$Working_days ;
                }
                
                if(request('Vdays') != "")
                {
                    $VWorking_days =implode( ",",request('Vdays') );  
                    $sehat->VWorking_days= $VWorking_days;
                }

                $sehat->id = Session::get('key');
                $id=Session::get('key');
                $sehat->About=request('about');
                $sehat->Qualification=request('qualification');
                $sehat->Services=request('services');
                $sehat->Experience=request('experience');
                $sehat->Experience_Time=$Exp_time;
                $sehat->Organization=request('organization');
                $sehat->Location=request('location');
                $sehat->City=request('city');
                $sehat->Time= $clinic_duration;
                $sehat->Duration=request('duration');
                $sehat->Fees=request('fees');
                $sehat->VTime=$video_duration;
                $sehat->VDuration=request('Vduration');
                $sehat->VFees=request('Vfees');
                
                if( $request->hasfile('image'))
                {
                    $image = $request->file('image');
                    $filename = time() . '.' . $image->getClientOriginalExtension();
                    Image::make($image)->resize(300, 300)->save( storage_path('uploads' . $filename ) );
                    $sehat->Image = $filename;
                    $doctor=DB::update( 'update profiles set Image=?, About= ?,Qualification=?,Services=?,Experience=?,Experience_Time=?,Organization=?,Location=?,City=?,Working_days=?,Time=?,Duration=?,Fees=?,VWorking_days=?, VTime=?,VDuration=?,VFees=? where id=?',[$sehat->Image,$sehat->About,$sehat->Qualification,$sehat->Services,$sehat->Experience,$sehat->Experience_Time,$sehat->Organization,$sehat->Location,$sehat->City,$sehat->Working_days,$sehat->Time,$sehat->Duration,$sehat->Fees,$sehat->VWorking_days,$sehat->VTime, $sehat->VDuration,$sehat->VFees,$sehat->id]);
                }
                else
                {
                    $doctor=DB::update( 'update profiles set About= ?,Qualification=?,Services=?,Experience=?,Experience_Time=?,Organization=?,Location=?,City=?,Working_days=?,Time=?,Duration=?,Fees=?,VWorking_days=?, VTime=?,VDuration=?,VFees=? where id=?',[$sehat->About,$sehat->Qualification,$sehat->Services,$sehat->Experience,$sehat->Experience_Time,$sehat->Organization,$sehat->Location,$sehat->City,$sehat->Working_days,$sehat->Time,$sehat->Duration,$sehat->Fees,$sehat->VWorking_days,$sehat->VTime, $sehat->VDuration,$sehat->VFees,$sehat->id]);
                }
                return redirect('E-SEHAT/editprofile')->with('success', 'Record Updated Successfullly!');
                
                
               
            }
    
        
    }
    public function reviews()
    {
        $id = Session::get('key');
        $doctor=$datas=DB::select( 'select * from  reviews where doctor_id=?',[$id]);
        $myArray = json_decode(json_encode($doctor), true);
        return view('E-SEHAT.docReviews',['reviews'=>$myArray]);

    }
    public function viewClinic()
    {
        $id = Session::get('key');
        $type="clinic";
        $doctor=DB::select( 'select * from  bookings where doctor_id=? and type=?',[$id,$type]);
        $myArray = json_decode(json_encode($doctor), true);
        if (!count($doctor ))
        {
            return view('E-SEHAT.docClinic')->with('user',$myArray)->with('success', 'You have no appointments!');
        }
        return view('E-SEHAT.docClinic',['user'=>$myArray]);

    }
    public function viewVideo()
    {
        $id = Session::get('key');
        $type="video";
        $doctor=DB::select( 'select * from  bookings where doctor_id=? and type=?',[$id,$type]);
        $myArray = json_decode(json_encode($doctor), true);
        if (!count($doctor ))
        {
            return view('E-SEHAT.docVideo')->with('doctor',$myArray)->with('success', 'You have no appointments!');
        }
        return view('E-SEHAT.docVideo',['doctor'=>$myArray]);

    }
   
  
    
    
    
}
