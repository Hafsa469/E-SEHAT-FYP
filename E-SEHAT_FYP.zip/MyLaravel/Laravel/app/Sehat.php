<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sehat extends Model
{
    //
}
