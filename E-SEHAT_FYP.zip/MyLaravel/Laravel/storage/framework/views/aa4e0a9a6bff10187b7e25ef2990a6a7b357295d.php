<?php $__env->startSection('title','Login Form'); ?>
<?php $__env->startSection('contents'); ?>

<?php echo e(csrf_field()); ?>



<div class="c_wrapper">
       <div >
              <div class="ad_form-wrapper">
                     <label class="lb">Phone #:</label><span id="ph">042-31458712</span >
                     <label class="lb">Email:</label><span id="em">info@e-sehat.com</span>
                     <div>
                            <label class="lb">Address:</label><br/>
                            <p id="add">5 SherShah Road, SherShah Block Garden Town, Lahore</p>
                     </div>

              </div>
       </div>
       <div class="c_form-wrapper">
              <form action="<?php echo e(url('/contact')); ?>" method="POST">
                     <?php if(count($errors) > 0): ?>
                            <div class = "alert alert-danger" id="cerrors">
                            <ul>
                                   <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <li><?php echo e($error); ?></li>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            </div>
                     <?php endif; ?>

              <?php echo e(csrf_field()); ?>

              <div>
                     <label>Name:</label>
                     <input type="text" size="10" name="name" placeholder="Your Name" class="doc" />

                     <label>Email:</label>
                     <input type="email" size="10" name="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$"  placeholder="Your Email" class="doc" />

              </div>
              <br/>
              <div>
                     <label>Phone:</label><br/>
                     <input type="text" pattern="[0]{1}[3]{1}[0-9]{9}" 
                            title="Phone number with 03 and remaing 9 digit with 0-9" maxlength=11 name="phone" placeholder="eg 0315" id="phone"/>
              </div><br/>
              <div>
                     <label>Message:</label><br/>
                     <textarea id="mess" rows=5 cols=100 name="message" placeholder="Type your Message here "></textarea>
              </div>
              <br/>
              <br/>
              <button class="btn btn-outline-primary"  id="ebtn" name="txtbutton" ><a >Submit</a></button>
              </form>


       </div>
</div>
<?php $__env->stopSection(); ?>











<?php echo $__env->make('layout.sehat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyLaravel\Laravel\resources\views/E-SEHAT/contact.blade.php ENDPATH**/ ?>