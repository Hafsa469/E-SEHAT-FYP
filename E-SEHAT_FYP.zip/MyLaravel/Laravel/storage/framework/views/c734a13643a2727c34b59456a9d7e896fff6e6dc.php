<?php $__env->startSection('title','Doctor Form'); ?>
<?php $__env->startSection('contents'); ?>

<?php echo e(csrf_field()); ?>



<div class="d_wrapper">
    <div class="mdp_form-wrapper">
            
            <br>
            <?php if(count($errors) > 0): ?>
                <div class = "alert alert-danger" id="cerrors">
                    <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
           
               
             <p><img src="/MyLaravel/Laravel/public/images/doctor.png" id="doutput" width="200" /></p>
             <?php if(!empty($success)): ?>
                <div class="alert alert-success" id="cerrors"> 
                <?php echo e($success); ?>

                </div>
                <button class="btn btn-info" onclick="back();" style="font-size:17px;font-family: 'Times New Roman', Times, serif; width:200px; height:40px; margin-left:400px; margin-top:10px;" name="txtbutton" ><a >Go Back to previous Page</a></button>
            <?php endif; ?> 
            <form>
            <?php echo e(csrf_field()); ?>

              
             
              <?php $__currentLoopData = $doctor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <?php if($key == 0): ?>
              <!-- Example single danger button -->
              <div class="btn-group dropright" style="margin-left: 300px; margin-top:11px;">
              <button type="button" class="btn btn-secondary btn-lg dropdown-toggle" id="write" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Sort the available doctors by their Fee Range  </button>
                     <ul class="dropdown-menu">
                            <li><a href="/MyLaravel/Laravel/public/E-SEHAT/0/<?php echo e($doctor['speciality']); ?>/<?php echo e($doctor['City']); ?>/fee">0-1000</a></li>
                            <li><a href="/MyLaravel/Laravel/public/E-SEHAT/1000/<?php echo e($doctor['speciality']); ?>/<?php echo e($doctor['City']); ?>/fee">1000-2000</a></li>
                            <li><a href="/MyLaravel/Laravel/public/E-SEHAT/2000/<?php echo e($doctor['speciality']); ?>/<?php echo e($doctor['City']); ?>/fee">2000-3000</a></li>
                            <li><a href="/MyLaravel/Laravel/public/E-SEHAT/3000/<?php echo e($doctor['speciality']); ?>/<?php echo e($doctor['City']); ?>/fee">3000-4000</a></li>
                            <li><a href="/MyLaravel/Laravel/public/E-SEHAT/4000/<?php echo e($doctor['speciality']); ?>/<?php echo e($doctor['City']); ?>/fee">4000-5000</a></li>
                     </ul>
              </div>
              
              <a href="/MyLaravel/Laravel/public/E-SEHAT/low/<?php echo e($doctor['speciality']); ?>/<?php echo e($doctor['City']); ?>/fee"><button class="btn btn-success"  style="font-size:17px;font-family: 'Times New Roman', Times, serif; width:250px; height:40px; margin-left:200px; margin-top:10px;" name="txtbutton" >Sort Fees From Low to High</button></a>
              <a href="/MyLaravel/Laravel/public/E-SEHAT/high/<?php echo e($doctor['speciality']); ?>/<?php echo e($doctor['City']); ?>/fee"><button class="btn btn-info" style="font-size:17px;font-family: 'Times New Roman', Times, serif; width:250px; height:40px; position:relative; left:100px; top:5px;" name="txtbutton" >Sort Fees From High to Low</button></a>
              
              <br>
              <?php endif; ?>

              <div class="clinic">
              <br><br>
              <div>
                     <p><img src="/MyLaravel/Laravel/storage/uploads<?php echo e($doctor['Image']); ?>" id="output" width="200" /></p>
              </div>
              <div style=" position:relative; left:250px; bottom:200px;">
                     <span class="red1"><u><?php echo e($doctor["name"]); ?></u></span><br>
                     <span class="red2"><?php echo e($doctor["designation"]); ?><span class="red2">,<span><span class="red2"><?php echo e($doctor["speciality"]); ?></span></span><br>
                     <span class="red1"><?php echo e($doctor["Organization"]); ?><span class="red1">,<span><span class="red1"><?php echo e($doctor["Location"]); ?></span></span><br>
                     <span class="red1"><?php echo e($doctor["City"]); ?><span class="red1">, Experience<span><span class="red1"><?php echo e($doctor["Experience_Time"]); ?></span></span>  
                     <br><span class="red2">Fees: <?php echo e($doctor["Fees"]); ?></span>
              </div>
              <div style=" position:relative; left:390px; bottom:350px;">
              <button class="btn btn-outline-primary"  id="e_btnn" name="txtbutton" ><a href='/MyLaravel/Laravel/public/E-SEHAT/<?php echo e($doctor["id"]); ?>/clinic'>Book In-Clinic Appointment</a></button>
              <button class="btn btn-outline-primary"  id="e_btnn" name="txtbutton" ><a href='/MyLaravel/Laravel/public/E-SEHAT/<?php echo e($doctor["id"]); ?>/video'>Book Video Consultation</a></button>
              <button class="btn btn-outline-primary"  id="e_btnn" name="txtbutton" ><a href='/MyLaravel/Laravel/public/E-SEHAT/<?php echo e($doctor["id"]); ?>/viewDocprofile'>View Profile</a></button>
              </div>
              <p class="fff" style=" position:relative; left:2px; bottom:240px; right:25px;"><span class="red2" style="font-size:20px;">Message: </span><?php echo e($doctor["message"]); ?></p>
             
   
              </div>
             
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </form>
    </div>
</div>       

<script>
function back()
{
    history.go(-1);
}

</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.sehat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyLaravel\Laravel\resources\views/E-SEHAT/viewdoctors.blade.php ENDPATH**/ ?>