<!DOCTYPE html>
<html>
<head>
    
    <title>App Name - <?php echo $__env->yieldContent('title'); ?></title>
    <!--
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::to('css/app.css')); ?>">-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>
    /*login*/
    #cerrors{
        font-family: "Times New Roman", Times, serif;
        position:absolute;
        width:300px;
        left:750px;
        top:730px;
        border:4px brown solid;
    }
    #errors
    {
        font-family: "Times New Roman", Times, serif;
        position:absolute;
        width:300px;
        left:500px;
        top:550px;
        border:4px brown solid;
    }
    #usererrors
    {
        font-family: "Times New Roman", Times, serif;
        position:absolute;
        width:300px;
        left:900px;
        top:350px;
        border:4px brown solid;
    }
    #error
    {
        font-family: "Times New Roman", Times, serif;
        position:absolute;
        width:300px;
        left:500px;
        top:40px;
        border:4px brown solid;
    }
#disease
{
  font-family: "Times New Roman", Times, serif;
    padding: 10px 350px 10px 5px;
    margin-bottom: 2px;
    margin-right: 10px;
    border-radius: 5px;
    outline:none;
}
input{
    font-family: "Times New Roman", Times, serif;
    padding: 10px 230px 10px 5px;
    margin-bottom: 2px;
    margin-right: 10px;
    border-radius: 5px;
    outline:none;
     
  }
  input::placeholder{
    font-family: "Times New Roman", Times, serif;
  
  }
.wrapper{
    height:100vh;
    width:100%;
    justify-content:center;
    /*background-color: darkcyan;
    background-repeat:no-repeat;
    background-size:100%;*/
    align-items: center;
    display:flex;
    flex-direction:column;
    background-image:url("/Laravel/Laravel/public/images/download.jpg");
    background-repeat:no-repeat;
    background-size: cover;
  
  }
  .form-wrapper{
    
    width:500px;
    height:500px;
    display:flex;
    flex-direction:column;
    padding: 20px 30px;
    border-radius: 10px;
    box-shadow: 0px 10px 50px #555;
    background-color: aliceblue;
    border:4px blue solid;
  
  }
  li{
    font-family: "Times New Roman", Times, serif; 
  }
  label{
    font-family: "Times New Roman", Times, serif;
    font-size: 17px;
    font-weight:lighter;
    margin-top:0px;
    margin-bottom: 1px;
    color: #222;
  }
  #btnn
  {
    width:120px;
    margin-left:150px;
    margin-top:4px;
    display: flex;
    align-items: center;
    flex-direction:column;
    font-family: "Times New Roman", Times, serif;
  }
  /*doctor login*/
  .d_form-wrapper{
      margin-top:10px;
    width:900px;
    height:900px;
    display:flex;
    flex-direction:column;
    padding: 20px 30px;
    border-radius: 10px;
    box-shadow: 0px 10px 50px #555;
    background-color: aliceblue;
    border:4px blue solid;
  
  }
  .d_wrapper{
    height:100%;
    width:100%;
    justify-content:center;
    /*background-color: darkcyan;
    background-repeat:no-repeat;
    background-size:100%;*/
    align-items: center;
    display:flex;
    flex-direction:column;
    background-image:url("/Laravel/Laravel/public/images/images.jpg");
    background-repeat:no-repeat;
    background-size: cover;
    image-rendering: -webkit-optimize-contrast;
  
  }
  .doc{

    font-family: "Times New Roman", Times, serif;
    height:40px;
    margin-bottom: 2px;
    border-radius: 5px;
    outline:none; 
  }
  .space{
      margin-top:70px;
  }
  .doc::placeholder{
    font-family: "Times New Roman", Times, serif; 
  }
  #mess{
    font-family: "Times New Roman", Times, serif; 
  }
  #d_btnn
  {
    width:120px;
    margin-left:350px;
    margin-top:2px;
    display: flex;
    align-items: center;
    flex-direction:column;
    font-family: "Times New Roman", Times, serif;
  }

  #style{
    font-family: "Times New Roman", Times, serif;
    height:70px;
    background-color:darkblue;
    color:white;
    margin-bottom:0px;
    
   } 

#col{
    color:white;
    margin-right:50px;
    font-size: 20px;
    border:1px solid black;
    padding:6px;
    
}
li a:hover{
  color:white;
}
#dist{
    padding-right:5px;
}
.img{
    background-image:url("./images/images.jpg");
    background-repeat:no-repeat;
    background-size: cover;
    width:100%;
    height:600px;
   
}
#para{
    font-family: Impact, Charcoal, sans-serif;
    font-weight: bold;
    color:black;
    font-size:35px;
    position: absolute;
    top:300px;
    left:100px;
}
#para1{
    font-family: Impact, Charcoal, sans-serif;
    color:darkblue;
    font-size:35px;
    position: absolute;
    top:340px;
    left:100px;
}
#para2{
    font-family: "Times New Roman", Times, serif;
    font-weight: normal;
    color:black;
    font-size:15px;
    position: absolute;
    top:390px;
    left:100px;
}
#sbtn{
    width:120px;
    position: absolute;
    top:440px;
    left:100px;
    display: flex;
    align-items: center;
    flex-direction:column;
    font-family: "Times New Roman", Times, serif;
}
#hbtnn{
  width:120px;
    margin-left:250px;
    margin-top:4px;
    display: flex;
    align-items: center;
    flex-direction:column;
    font-family: "Times New Roman", Times, serif;
}
#lbtn{
    width:120px;
    position: absolute;
    top:440px;
    left:250px;
    display: flex;
    align-items: center;
    flex-direction:column;
    background-color: white;
    font-family: "Times New Roman", Times, serif;
}
Button a:hover {
  color:black;
}
.imge{
    margin-left:60px;
}
#icon{
    margin-left:900px;
    height:30px;
    position:absolute;
    top:40px;
    left:240px;
}
.search{
    margin-left:450px;
}
/*Contact*/
.c_form-wrapper{
      margin-top:10px;
    width:900px;
    height:500px;
    display:flex;
    flex-direction:column;
    padding: 20px 30px;
    border-radius: 10px;
    box-shadow: 0px 10px 50px #555;
    background-color: aliceblue;
    border:4px blue solid;
  
  }
  .c_wrapper{
    height:100vh;
    width:100%;
    justify-content:center;
    align-items: center;
    display:flex;
    flex-direction:column;
    background-image:url("/Laravel/Laravel/public/images/images.jpg");
    background-repeat:no-repeat;
    background-size: cover;
    
  
  }
  .ad_form-wrapper{
      margin-top:10px;
    width:900px;
    height:200px;
    display:flex;
    flex-direction:column;
    padding: 20px 30px;
    border-radius: 10px;
    box-shadow: 0px 10px 50px #555;
    background-color: aliceblue;
    border:4px blue solid;
  
  }
  #ph,#em,#add{
    font-family: "Times New Roman", Times, serif;
      background-color:white;
  }
  .lb{
      font-weight:bold;
  }
  .ddform-wrapper{
    
    width:700px;
    height:300px;
    display:flex;
    flex-direction:column;
    padding: 20px 30px;
    border-radius: 10px;
    box-shadow: 0px 10px 50px #555;
    background-color: aliceblue;
    border:4px blue solid;
  
  }
  .nform-wrapper{
    
    width:1100px;
    height:650px;
    display:flex;
    flex-direction:column;
    padding: 20px 30px;
    border-radius: 10px;
    box-shadow: 0px 10px 50px #555;
    background-color: aliceblue;
    border:4px blue solid;
  
  }
  td{
    font-family: "Times New Roman", Times, serif;
    background-color:white;
    font-size:20px;
  }
  th{
    font-family: "Times New Roman", Times, serif;
    background-color:darkblue;
    color:white;
    font-size:25px;
    text-align:center;
  }
  tr{
    background-color:darkblue;
  }
  #no{
    font-weight:bold;
    font-size:22px;
  }
  #data{
    margin-left:10px;
    margin-right:250px;
    text-align:justify;
    
  }
  #data2{
    margin-left:10px;
    text-align:center;
    
  }
  #click{
    font-family: "Times New Roman", Times, serif;
    color:darkblue;
    font-size:25px;
    font-weight:bold;
    text-align:center;
  }
.doc1{

font-family: "Times New Roman", Times, serif;
height:40px;
width:300px;
margin-bottom: 2px;
border-radius: 5px;
outline:none; 
}
#head{
  font-family: "Times New Roman", Times, serif;
  text-align:center;
  margin-left:100px;
}
#headr{
  margin-top:5px;
  font-family: "Times New Roman", Times, serif;
  text-align:center;
  background-color:White;
  color:darkblue;
}
#head1{
  text-align:center;
  font-family: "Times New Roman", Times, serif;
    background-color:darkblue;
    color:white;
    font-size:25px;
    text-align:center;
    font-weight:bold;
}
#data1{
    font-family: "Times New Roman", Times, serif;
    margin-left:20px;
    font-weight:bold;
    padding:8px;
    
  }
table{
  
  width:850px;
}
#form{
  width:1030px;
}
#doc2{

font-family: "Times New Roman", Times, serif;
height:40px;
width:250px;
margin-bottom: 2px;
color:blue;
outline:none; 
margin-left:50px
}
#out{
  font-weight:bold;
  font-size:25px;
  color:darkblue;
  font-family: "Times New Roman", Times, serif;
}
    </style>
</head>
<body>
<div>
<img src="/Laravel/Laravel/public/images/Capture.PNG" class="imge" />  
<input type="text" class="search" placeholder="Search For Doctors "/>
<i class="fa fa-search" id="icon"></i> 
<span id="out"><a href="<?php echo e(url('/E-SEHAT/log')); ?>">Logout</a></span>
</div>
<nav class="navbar navbar-expand-sm  navbar-light" id="style">
            
            <div class="container">
        
            
                <ul class="navbar-nav right">
                    <li id="col"><i class="fa fa-home"></i> <a href="<?php echo e(url('/E-SEHAT/menu')); ?>">Home</a></i> </li>  
                    <li id="col"><a href="<?php echo e(url('/E-SEHAT/doctorLogin')); ?>">Join as Doctor</a></li>  
                    <li id="col"><a href="signup.html">Doctors</a></li>
                    <li id="col"><a href="<?php echo e(url('/E-SEHAT/diagonosis')); ?>">Disease Detection</a></li>
                    <li id="col"><a href="<?php echo e(url('/E-SEHAT/nutrition')); ?>">Health & Nutrition</a></li>
                    <li id="col"><a href="<?php echo e(url('/E-SEHAT/contact')); ?>">Contact Us</a></li>
                    
                </ul>
            </div>
</nav>

    
    <?php echo $__env->yieldContent('contents'); ?>
   
    <!--<p><small>Copyrights&copy; <?php echo e(date('Y')); ?></small></p>-->
    <script src="<?php echo e(asset('java/app.js')); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\Laravel\Laravel\resources\views/layout/sehat.blade.php ENDPATH**/ ?>