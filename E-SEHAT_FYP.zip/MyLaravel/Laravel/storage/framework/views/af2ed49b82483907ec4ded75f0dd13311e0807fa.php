<!DOCTYPE html>
<html>
<head>
    
    <title>App Name - <?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/app.css')); ?>">
    
</head>
<body>

    <h1>Welcome To HomePage!</h1>
    <?php echo $__env->yieldContent('contents'); ?>
    <p><small>Copyrights&copy; <?php echo e(date('Y')); ?></small></p>
    <script src="<?php echo e(asset('java/app.js')); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\Laravel\Laravel\resources\views/layout/layout.blade.php ENDPATH**/ ?>