<?php $__env->startSection('title','Doctor Profile Form'); ?>
<?php $__env->startSection('contents'); ?>

<?php echo e(csrf_field()); ?>



<div class="d_wrapper">
    <div class="mdp_form-wrapper">
                <br>
                <?php if(count($errors) > 0): ?>
                     <div class = "alert alert-danger" id="cerrors">
                     <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </ul>
                     </div>
              <?php endif; ?>              
              <?php if(session()->has('success')): ?>
                     <div class="alert alert-success" id="cerrors" >
                     <?php echo e(session()->get('success')); ?>

                     </div>
              <?php endif; ?> 
              <form>
              <?php echo e(csrf_field()); ?>

              
              <div>
                     <p><img src="/MyLaravel/Laravel/storage/uploads<?php echo e($doctor['Image']); ?>" id="output" width="200" /></p>
              </div>
              <div class="info">
                     <span class="ffi"><u><?php echo e($doctor["name"]); ?></u></span><br>
                     <span class="red2"><?php echo e($doctor["designation"]); ?><span class="red2">,<span><span class="red2"><?php echo e($doctor["speciality"]); ?></span></span><br>
                     <span class="ffi"><?php echo e($doctor["phone"]); ?></span><br>
                     <span class="ffi"><?php echo e($doctor["Experience_Time"]); ?><span class="ffi">Experience <span></span>
              </div>
              <div style="position:relative; bottom:40px">
                <label  class="ff">Personel Information:</label><br/>
                <textarea id="mess" rows=5 cols=120 name="about" placeholder="Type about yourself here " readonly><?php echo e($doctor['About']); ?></textarea>
              </div>
              <div style="position:relative; bottom:20px" >
                <label  class="ff">Qualification:</label><br/>
                <textarea id="mess" rows=5 cols=120 name="qualification" placeholder="Type your Qualification here " readonly ><?php echo e($doctor['Qualification']); ?></textarea>
              </div>
              <div>
                <label  class="ff">Services:</label><br/>
                <textarea id="mess" rows=5 cols=120 name="services" placeholder="Type your Services here " readonly><?php echo e($doctor['Services']); ?></textarea>
              </div><br>
              <div>
                <label  class="ff">Working Experience:</label><br/>
                <textarea id="mess" rows=5 cols=120 name="experience" placeholder="Type your Experience here " readonly><?php echo e($doctor['Experience']); ?></textarea>
              </div>

              <div class="clinics">
              <br>
                     <h2>Organization Address</h2>
                     <div>
                            <label  class="ff">Working Organization:</label>
                            <span class="fff"><?php echo e($doctor['Organization']); ?></span><br>
                            <label  class="ff">Location:</label>
                            <span class="fff"><?php echo e($doctor['Location']); ?></span><br>
                            <label  class="ff">City:</label>
                            <span class="fff"><?php echo e($doctor['City']); ?></span>
                     </div>
              <br>
              </div>
              </form>
              <form action="<?php echo e(url('/bookclinic')); ?>" method="POST">
              <?php echo e(csrf_field()); ?>

              <div class="clinics">
              <br>
                     <h2>In-Clinic Appointement</h2>
                     <div>
                            <br>
                            <img src="/MyLaravel/Laravel/public/images/video.png" class="image" /> <br>
                            <label class="ff">Available Days:</label>
                            <span class="red2"><?php echo e($doctor['Working_days']); ?></span><br>

                            <label class="ff">Available Timings:</label>
                            <span class="red2"><?php echo e($doctor['TimeArray']); ?></span><br>
                            
                            <label class="ff">Appointement Duration:</label>
                            <span class="fff"><?php echo e($doctor['Duration']); ?></span>  <span class="fff">minutes</span>
                               
                     </div>
                     <div>
                            <label class="ff">Fees:</label>
                            <span class="fff"><?php echo e($doctor['Fees']); ?></span>
                            
                     </div>
                     <div class="book">
                     <br>
                        <h3 class="ff" style="font-size:20px;"><u>Add Patient Details:</u></h3>
                        <div class="btn btn-danger" id="phoneicon" onclick="call();"><i class="fa fa-phone" > Call</i></div><br>
                        <label class="ff">Name:</label>
                        <input type="text" name="name" placeholder="Name" id="name"/>
                        <label class="ff">Phone:</label>
                        <input type="text" pattern="[0]{1}[3]{1}[0-9]{9}" title="Phone number with 03 and remaing 9 digit with 0-9" maxlength=11 name="phone" placeholder="eg 0315" id="phone"/>
                        <label class="ff">Select Date:</label>
                        <input type="date" name="selectedDate" min="2021-03-01" max="2021-03-31" />
                        <label class="ff">Select Time:</label>
                        <input type="time" name="selectedTime"  />
                        <input type="hidden" name="id" value="<?php echo e($doctor['id']); ?>" />
                        <input type="hidden" name="tcarray" value="<?php echo e($doctor['TimeArray']); ?>" />
                        <input type="hidden" name="cworking" value="<?php echo e($doctor['Working_days']); ?>" />
                        <br><br>
                        <button class="btn btn-outline-success"  id="e_btnn" class="Vbutton" ><a >Book InClinic Appointment</a></button>
                    <br>
                     </div>
                    
              <br><br>
              </div>
              </form>
              <form action="<?php echo e(url('/bookvideo')); ?>" method="POST">
              <?php echo e(csrf_field()); ?>

              <div class="videos">
              <br>
                     <h2>Video Consultation</h2>
                     <div>
                            <br>
                            <img src="/MyLaravel/Laravel/public/images/clinic.png" class="image" /> <br>
                            <label class="ff">Available Days:</label>
                            <span class="red2"><?php echo e($doctor['VWorking_days']); ?></span><br>
                            <label class="ff">Available Timings:</label>
                            <span class="red2"><?php echo e($doctor['VTimeArray']); ?></span><br>
                            <label class="ff">Appointement Duration:</label>
                            <span class="fff"><?php echo e($doctor['VDuration']); ?></span><span class="fff">minutes</span>                         
                     </div>
                     <div>    
                            <label class="ff">Fees:</label>
                            <span class="fff"><?php echo e($doctor['VFees']); ?></span>
                            
                     </div>
                     <div class="book">
                     <br>
                        <h3 class="ff" style="font-size:20px;"><u>Add Patient Details:</u></h3>
                        <div class="btn btn-danger" id="phoneicon" onclick="call();"><i class="fa fa-phone" > Call</i></div><br>
                        <label class="ff">Name:</label>
                        <input type="text" name="name" placeholder="Name" id="name"/>
                        <label class="ff">Phone:</label>
                        <input type="text" pattern="[0]{1}[3]{1}[0-9]{9}" title="Phone number with 03 and remaing 9 digit with 0-9" maxlength=11 name="phone" placeholder="eg 0315" id="phone"/>
                        <label class="ff">Select Date:</label>
                        <input type="date" name="VselectedDate" min="2021-03-01" max="2021-03-31" />
                        <label class="ff">Select Time:</label>
                        <input type="time" name="VselectedTime"  />
                        <input type="hidden" name="id" value="<?php echo e($doctor['id']); ?>" />
                        <input type="hidden" name="tarray" value="<?php echo e($doctor['VTimeArray']); ?>" />
                        <input type="hidden" name="working" value="<?php echo e($doctor['VWorking_days']); ?>" />
                        <br><br>
                        <button class="btn btn-outline-danger"  id="e_btnn" class="Vbutton" ><a >Book Video Consultation</a></button>
                    <br>
                     </div>
                     
              <br>
              </div>
             
              </form>
              <form action="<?php echo e(url('/reviews')); ?>" method="post">
              <?php echo e(csrf_field()); ?>

              
              <div class="book">
                     <br>
                     <h2>Reviews Form</h2><br>
                        <label class="ff">Name:</label>
                        <input type="text" name="rname" placeholder="Name" id="name"/><br>
                        <label class="ff">Write Reviews:</label>
                        <textarea id="mess" rows=5 cols=120 name="reviews" placeholder="Type your Reviews here " style="margin-left:10px;" ></textarea>
                        <br><br>
                        <button class="btn btn-outline-info"  id="e_btnn" class="Vbutton" ><a >Submit</a></button>
                    <br>
                </div>
                </form>
             
            

       


    </div>
</div>       

<script>
function call()
{
   //alert(" Call E-SEHAT Helpline (8:00 AM - 12:00 PM)\n Call 03245334289\n OR\n Call 03127179923 ");
   swal("Call E-SEHAT Helpline (8:00 AM - 12:00 PM)", "Call 03245334289, Call 03127179923");
}
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.sehat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyLaravel\Laravel\resources\views/E-SEHAT/viewprofile.blade.php ENDPATH**/ ?>