<?php $__env->startSection('title','Login Form'); ?>
<?php $__env->startSection('contents'); ?>

<?php echo e(csrf_field()); ?>



<div class="wrap">
       <div class="ddform-wrapper">
    
<form action="<?php echo e(url('/diagonosis')); ?>" method="POST">
<?php echo e(csrf_field()); ?>

<div>
<label id="click">For Disease Diagonosis Just Click on the Start button below:</label><br/>
</div>
<br/>
<button class="btn btn-outline-primary"  id="hbtnn" name="txtbutton" ><a >Start</a></button>
</form>



</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.sehat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyLaravel\Laravel\resources\views/E-SEHAT/diagonosis.blade.php ENDPATH**/ ?>