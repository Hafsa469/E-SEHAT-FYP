<?php $__env->startSection('title','Doctor Form'); ?>
<?php $__env->startSection('contents'); ?>

<?php echo e(csrf_field()); ?>



<div class="d_wrapper">
    <div class="mdp_form-wrapper">
                
                <br><br>
                
              
              <h1 class="hdng" style="align:center"><u>Video Appointments</u> </h1><br/>
             
              <?php if(!empty($success)): ?>
                <div class="alert alert-success" id="cerrors"> 
                <?php echo e($success); ?>

                </div>
              <?php endif; ?>
             <?php $__currentLoopData = $doctor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <form method='post' action="/MyLaravel/Laravel/public/E-SEHAT/<?php echo e($doctor['booking_id']); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
              <div class="clinics">
              <br>
              
              <div class="pinfo">
                     <span class="ff">Patient Name:  <span class="red2"><?php echo e($doctor["bname"]); ?></span></span><br>
                     <span class="ff">Patient Phone No:  <span class="red2"><?php echo e($doctor["bphone"]); ?></span></span><br>
                     <span class="ff">Date:  <span class="red2"><?php echo e($doctor["date"]); ?></span></span><br>
                     <span class="ff">Day:  <span class="red2"><?php echo e($doctor["day"]); ?></span></span><br>
                     <span class="ff">Time:  <span class="red2"><?php echo e($doctor["time"]); ?></span></span>
              </div>
              <button class="btn btn-outline-danger"  id="e_btnn" name="txtbutton" ><a>Remove</a></button><br>
              </div>
             </form>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
              
    </div>
</div>       




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.doctor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyLaravel\Laravel\resources\views/E-SEHAT/docVideo.blade.php ENDPATH**/ ?>