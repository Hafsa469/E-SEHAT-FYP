<?php $__env->startSection('title','Login Form'); ?>
<?php $__env->startSection('contents'); ?>
<h1>Hafsa</h1>
<div class="container">

<form action="<?php echo e(url('/forms')); ?>" method="POST">
<?php echo e(csrf_field()); ?>

<div>
<label>Name</label>
<input type="text" name="name" placeholder="Name"/>
</div>
<div>
<label>Password</label>
<input type="password" name="password" placeholder="Password"/>
</div>
<div>
<label>Email</label>
<input type="email" name="email" placeholder="Email"/>
</div>
<button>Submit</button>
</form>
<?php if(session('message')): ?>
<p class="alert alert-success"><?php echo e(session('message')); ?></p>
<?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Laravel\resources\views/forms/create.blade.php ENDPATH**/ ?>