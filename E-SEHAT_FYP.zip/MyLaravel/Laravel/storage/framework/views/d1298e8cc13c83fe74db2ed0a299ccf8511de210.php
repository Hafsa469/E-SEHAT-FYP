<?php $__env->startSection('title','Symptoms Form'); ?>
<?php $__env->startSection('contents'); ?>

<?php echo e(csrf_field()); ?>



<div class="d_wrapper">
       <div class="md_form-wrapper">
    
<form action="<?php echo e(url('/results')); ?>" method="POST">
<?php echo e(csrf_field()); ?>

<table>
<tbody>
<thead>
    
    <th id="head">Search Related To Your Symptoms Experienced</th>
    <th><p id="headr">Select among the 4 DropDown Options</p></th>
    <th><p id="headrr">Symptom Description</p></th>
    
   
</thead>
<?php $i=0 ?>
    <?php $__currentLoopData = $result_ar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $result_ar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
        <tr>
            <td>
                <span id="no"><?php echo $i.")"; $i++; ?></span><span id="data"><?php echo e($result_ar); ?></span>


            </td>
            <td>
                <select name="postive[]" id="doc2" >
                    <option value=<?php echo e($result_ar); ?>>Agreed</option>
                    <option value=<?php echo e($result_ar); ?>>Strongly Agreed</option>
                    <option value=<?php echo e($result_ar); ?>>Weekly Agreed</option>
                    <option value="">Disagreed</option>
                </select>
            </td>
            <td>     
            <!--<a href='/MyLaravel/Laravel/public/E-SEHAT/<?php echo e($result_ar); ?>/symptomDetails'><button class="btn btn-outline-success"  id="md" name="txtbutton" >Details</button> </a> -->      
            <button class="btn btn-outline-success"  id="md" name="txtbutton" ><a href='/MyLaravel/Laravel/public/E-SEHAT/<?php echo e($result_ar); ?>/symptomDetails'>Details</a></button>            
            </td>
        </tr> 
       
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tbody>
</table>
<br/><br/>
<button class="btn btn-outline-primary"  id="d_btnn" name="txtbutton" ><a >Submit</a></button>
</form>


</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.sehat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyLaravel\Laravel\resources\views/E-SEHAT/symptoms.blade.php ENDPATH**/ ?>