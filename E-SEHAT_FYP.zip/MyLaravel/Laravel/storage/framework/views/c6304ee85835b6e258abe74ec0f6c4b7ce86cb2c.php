<?php $__env->startSection('title','Doctor Registration Form'); ?>
<?php $__env->startSection('contents'); ?>

<?php if(count($errors) > 0): ?>
         <div class = "alert alert-danger" id="errors">
            <ul>
               <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
         </div>
<?php endif; ?>

<div class="d_wrapper">
       <div class="d_form-wrapper">
    
<form action="<?php echo e(url('/doctorLogin')); ?>" method="POST">
<?php echo e(csrf_field()); ?>

<div class="space"></div>
<div>
<label>Name:</label>
<input type="text" size="10" name="name" placeholder="Your Name" class="doc" />

<label>Email:</label>
<input type="email" size="10" name="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" placeholder="Your Email" class="doc" />

</div>
<br/>
<div> 
<label>Phone #:</label>
<input type="text" size="10" pattern="[0]{1}[3]{1}[0-9]{9}" 
       title="Phone number with 03 and remaing 9 digit with 0-9" maxlength="11" name="phone" placeholder="eg 0315"  class="doc" />

<label>City:</label>
<input type="text" size="9" name="city" placeholder="Your City" class="doc"/>

</div>
<br/>
<div>
<label>Designation:</label>
<input type="text" size="6" name="designation" placeholder="Designation" class="doc" />

<label>Speciality:</label>
<input type="text" size="5" name="speciality" placeholder="Speciality" class="doc" />
</div>
</br/>

<div>
<label>PMDC #:</label>
<input type="text" size="3" placeholder="PMDC" name="pmdc" class="doc"  id="pmdc"/>

<label>Choose Password:</label>
<input type="password" size="4" name="password"  maxlength="6" placeholder="Password" class="doc" id="pass"/>
</div><br>
<div>
<label>Upload CV:</label><br/>
<input type="file" name="cv"  id="cv"/>
</div>
<div>
<label>Message:</label><br/>
<textarea id="mess" rows=5 cols=100 placeholder="Type your Message here "></textarea>
</div>
<br/>
<button class="btn btn-outline-primary"  id="d_btnn" name="txtbutton" ><a >Submit</a></button>


</form>


</div>
</div>
<?php $__env->stopSection(); ?>











<?php echo $__env->make('layout.sehat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Laravel\resources\views/E-SEHAT/doctorLogin.blade.php ENDPATH**/ ?>