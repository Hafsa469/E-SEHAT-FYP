<?php $__env->startSection('title','About'); ?>
<?php $__env->startSection('contents'); ?>
<h1>My name is hafsa riaz</h1>
<a href="<?php echo e(action('StudentController@index')); ?>">Home</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Laravel\resources\views/about.blade.php ENDPATH**/ ?>