<html>
<head>
<head>
<body>
<p> just get lost from my life </p>
</body>

</html><?php /**PATH C:\xampp\htdocs\Laravel\Laravel\resources\views/contact.blade.php ENDPATH**/ ?>