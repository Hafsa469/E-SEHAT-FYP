@extends('layout.sehat')
@section('title','Results Form')
@section('contents')

{{csrf_field()}}


<div class="d_wrapper">
       <div class="d_form-wrapper">
    
<form action="{{url('/results')}}" method="POST">
{{csrf_field()}}
<table>
<tbody>
<thead>
    <th id="head">Outcomes</p></th>
</thead>
<?php $i=1 ?>
    @foreach($result_ar as $key => $result_ar)
    @if (($key) == 0)
        <tr>
            <td>
                <br>
                <div class="alert alert-warning">
                    <strong>Warning!</strong> {{$result_ar}}
                </div>
               <br/>
            </td>
        </tr> 
    @endif
    @if (($key) == 1)
        <tr>
            <td>
               <span id="head1">Predicted Disease:</span><span class="alert alert-danger" id="data1">{{$result_ar}}</span>
            </td>
        </tr> 
    @endif
    
    @if (($key) == 2)
        <tr>
            <td>
                <br/>
                <p id="head1">Disease Description</p>
                <span  id="data">{{$result_ar}}</span>

            </td>
        </tr> 
    @endif  
    
    @if (($key) == 3)
        <tr>
            <td>
                <br/>
                <p id="head1">{{$result_ar}}</p>

            </td>
        </tr> 
    @endif  
    @if (($key) > 3) 
        <tr>
            <td>
                <span id="no"><?php echo $i.")"; $i++; ?></span><span id="data">{{$result_ar}}</span>

            </td>
        </tr>
    @endif  
    @endforeach
    <tbody>
</table>

</form>
<button class="btn btn-outline-primary"  id="docbtn" name="txtbutton" ><a href="{{url('/E-SEHAT/doctor')}}" >Meet Your Doctor</a></button>
<button class="btn btn-outline-success"  id="dietbtn" name="txtbutton" ><a href="{{url('/E-SEHAT/dietPlans')}}">Nutritionist Diet Plans</a></button>

</div>
</div>



@endsection