@extends('layout.doctor')
@section('title','Doctor Form')
@section('contents')

{{csrf_field()}}


<div class="d_wrapper">
    <div class="mdp_form-wrapper">
                
                <br><br>
                
              
              <h1 class="hdng" style="align:center"><u>Video Appointments</u> </h1><br/>
             
              @if(!empty($success))
                <div class="alert alert-success" id="cerrors"> 
                {{ $success}}
                </div>
              @endif
             @foreach($doctor as $key => $doctor)
              <form method='post' action="/MyLaravel/Laravel/public/E-SEHAT/{{$doctor['booking_id']}}">
                @csrf
                @method('DELETE')
              <div class="clinics">
              <br>
              
              <div class="pinfo">
                     <span class="ff">Patient Name:  <span class="red2">{{$doctor["bname"]}}</span></span><br>
                     <span class="ff">Patient Phone No:  <span class="red2">{{$doctor["bphone"]}}</span></span><br>
                     <span class="ff">Date:  <span class="red2">{{$doctor["date"]}}</span></span><br>
                     <span class="ff">Day:  <span class="red2">{{$doctor["day"]}}</span></span><br>
                     <span class="ff">Time:  <span class="red2">{{$doctor["time"]}}</span></span>
              </div>
              <button class="btn btn-outline-danger"  id="e_btnn" name="txtbutton" ><a>Remove</a></button><br>
              </div>
             </form>
              @endforeach
              
              
    </div>
</div>       




@endsection