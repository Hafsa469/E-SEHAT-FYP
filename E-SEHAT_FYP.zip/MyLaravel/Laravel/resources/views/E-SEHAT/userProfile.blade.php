@extends('layout.sehat')
@section('title','Doctor Form')
@section('contents')

{{csrf_field()}}


<div class="d_wrapper">
    <div class="md_form-wrapper">
          
                <br><br>
                
              <h1 class="hdng" style="text-align:center"><u> Your Appointments</u> </h1><br>
              @if(!empty($success))
                <div class="alert alert-success" id="cerrors"> 
                {{ $success}}
                </div>
              @endif
              @foreach($doctor as $key => $doctor)
              <form method='post' action="/MyLaravel/Laravel/public/E-SEHAT/{{$doctor['booking_id']}}">
                @csrf
                @method('DELETE')
              <div class="Uclinic">
              <br>
              <div>
                     <p><img src="/MyLaravel/Laravel/storage/uploads{{$doctor['Image']}}" id="output" width="200" /></p>
              </div>
              <div class="info">
                     <span class="ffi"><u>{{$doctor["name"]}}</u></span><br>
                     <span class="red2">{{$doctor["designation"]}}<span class="red2">,<span><span class="red2">{{$doctor["speciality"]}}</span></span><br>
                     <span class="ffi">{{$doctor['Organization']}}<span class="ffi">,<span><span class="ffi">{{$doctor["Location"]}}</span></span><br>
                     <span class="ffi">{{$doctor['City']}}<span class="ffi">,<span><span class="ffi">{{$doctor["Experience_Time"]}}</span><span class="ffi">Experience <span></span>
              </div>
              <button class="btn btn-outline-primary" style="position:relative; bottom:190px; right:120px;" id="e_btnn" name="txtbutton" ><a href="/MyLaravel/Laravel/public/E-SEHAT/{{$doctor['id']}}/viewDocprofile">View Profile</a></button>
              <div class="btn btn-danger" id="phonei" style="position:relative; bottom:230px; left:515px;" onclick="call();"><i class="fa fa-phone" > Call</i></div>
              <div  style="position:relative; bottom:150px; left:20px;">
                     <span class="ff">Patient Name:  <span class="red2">{{$doctor["bname"]}}</span></span><br>
                     <span class="ff">Patient Phone No:  <span class="red2">{{$doctor["bphone"]}}</span></span><br>
                     <span class="ff">Appointment Date:  <span class="red2">{{$doctor["date"]}}</span></span><br>
                     <span class="ff">Appointment Type:  <span class="red2">{{$doctor["type"]}}</span></span><br>
                     <span class="ff">Appointment Day:  <span class="red2">{{$doctor["day"]}}</span></span><br>
                     <span class="ff">Appointment Time:  <span class="red2">{{$doctor["time"]}}</span></span>
                     
              </div>
              <button class="btn btn-outline-danger"  id="e_btnn" name="txtbutton"  style="position:relative; bottom:120px"><a >Remove</a></button><br>
              </div>
             </form>
              @endforeach
              
              
    </div>
</div>       


<script>
function call()
{
   //alert(" Call E-SEHAT Helpline (8:00 AM - 12:00 PM)\n Call 03245334289\n OR\n Call 03127179923 ");
   swal("Call E-SEHAT Helpline (8:00 AM - 12:00 PM)", "Call 03245334289, Call 03127179923");
}
</script>

@endsection