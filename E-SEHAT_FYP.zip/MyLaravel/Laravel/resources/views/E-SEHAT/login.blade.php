@extends('layout.sehat')
@section('title','Login Form')
@section('contents')





<div class="wrapper">
       <div class="form-wrapper">
       @if (count($errors) > 0)
         <div class = "alert alert-danger" id="cerrors">
            <ul>
               @foreach ($errors->all() as $error)
                  <li>{{ $error }}</li>
               @endforeach
            </ul>
         </div>
      @endif

      @if(session()->has('error'))
         <div class="alert alert-danger" id="cerrors">
            {{ session()->get('error') }}
         </div>
      @endif
      @if(session()->has('success'))
         <div class="alert alert-success" id="success" >
            {{ session()->get('success') }}
         </div>
      @endif 
<form action="{{url('/login')}}" method="POST">
{{csrf_field()}}


<div>
<label>Email:</label><br/>
<input type="email" name="email" placeholder="Email" id="email"/>
</div>
<br/>

<div>
<label>Password:</label><br/>
<input type="password" name="password" placeholder="Password" id="pass"/>
</div>
<br/>
<button class="btn btn-outline-primary"  id="btnn" name="txtbutton" ><a >Login</a></button>
</form>


</div>
</div>
@endsection










