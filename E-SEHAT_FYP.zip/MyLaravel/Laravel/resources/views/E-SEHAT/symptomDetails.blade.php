@extends('layout.sehat')
@section('title','Symptoms Form')
@section('contents')

{{csrf_field()}}


<div class="d_wrapper">
       <div class="d_form-wrapper">
    
<form >
{{csrf_field()}}
<table>
<tbody>
    @foreach($data as $key => $result_ar)
        @if (($key) == 0)
            <tr>
                <td>
                    <br>
                    <div class="alert alert-danger">
                        <strong>Symptom:</strong> {{$result_ar}}
                    </div>
                
                </td>
            </tr> 
        @endif
        @if (($key) == 1)
            <tr>
                <td>
                    <br>
                    <div class="alert alert-warning">
                        <strong>Symptom Meaning:</strong> {{$result_ar}}
                    </div>
                
                </td>
            </tr> 
        @endif
        @if (($key) == 2)
            <tr>
                <td>
                <div class="alert alert-info">
                        <strong>Symptom Description:</strong> {{$result_ar}}
                    </div>
                </td>
            </tr> 
        @endif
    
       
    @endforeach
    <tbody>
</table>
<br/><br/>

</form>

<button class="btn btn-outline-primary"  id="e_btn" name="txtbutton" onclick="back();" ><a >Back</a></button>
</div>
</div>
<script>
function back()
{
    history.go(-1);
}

</script>
@endsection