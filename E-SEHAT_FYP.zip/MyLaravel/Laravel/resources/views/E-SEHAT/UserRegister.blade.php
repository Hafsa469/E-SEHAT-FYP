@extends('layout.sehat')
@section('title','Registration Form')
@section('contents')




<div class="wrapper">
       <div class="form-wrapper">
    
<form action="{{url('/UserRegister')}}" method="POST">
@if (count($errors) > 0)
         <div class = "alert alert-danger" id="cerrors">
            <ul>
               @foreach ($errors->all() as $error)
                  <li>{{ $error }}</li>
               @endforeach
            </ul>
         </div>
@endif
{{csrf_field()}}
<div>
<label>Name:</label><br/>
<input type="text" name="name" pattern="[A-Z][a-z]*{2,}" title="Enter Your Full Name of atleast two words" placeholder="Name" id="name"/>
</div>
<br/>

<div>
<label>Email:</label><br/>
<input type="email" name="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" placeholder="Email" id="email"/>
</div>
<br/>
<div>
<label>Phone:</label><br/>
<input type="text" pattern="[0]{1}[3]{1}[0-9]{9}" 
       title="Phone number start with 03 and remaining 9 digit with 0-9" maxlength=11 name="phone" placeholder="eg 0315" id="phone"/>
</div>
<br/>
<div>
<label>Password:</label><br/>
<input type="password" name="password" pattern=".{6,}" title="Six or more characters" placeholder="Password" id="pass"/>
</div>
<br/>
<button class="btn btn-outline-primary"  id="btnn" name="txtbutton" ><a >Submit</a></button>
</form>


</div>
</div>
@endsection










