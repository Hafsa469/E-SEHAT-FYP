@extends('layout.doctor')
@section('title','Doctor Profile Form')
@section('contents')

{{csrf_field()}}


<div class="d_wrapper">
    <div class="mdp_form-wrapper">
                <h1>Complete Your Profile First</h1>
                <br>
              <form action="{{url('/profile')}}" method="POST" enctype="multipart/form-data">
                     @if (count($errors) > 0)
                            <div class = "alert alert-danger" id="cerrors">
                            <ul>
                                   @foreach ($errors->all() as $error)
                                   <li>{{ $error }}</li>
                                   @endforeach
                            </ul>
                            </div>
                     @endif
                     @if(session()->has('success'))
                            <div class="alert alert-success" id="success" >
                            {{ session()->get('success') }}
                            </div>
                     @endif 

              {{csrf_field()}}
             
              <div>
                     <p><input type="file"  accept="image/*" name="image" id="file"  onchange="loadFile(event)" style="display: none;"></p>
                     <p><label for="file" class="ff" style="cursor: pointer;">Upload Image:</label><img id="output" width="200" /></p>
                     
              </div>
       
              <div>
                <label  class="ff">Personel Information:</label><br/>
                <textarea id="mess" rows=5 cols=100 name="about" placeholder="Type about yourself here "></textarea>
              </div>
              <div>
                <label  class="ff">Enter Your Qualification:</label><br/>
                <textarea id="mess" rows=5 cols=100 name="qualification" placeholder="Type your Qualification here "></textarea>
              </div>
              <div>
                <label  class="ff">Enter Your Services:</label><br/>
                <textarea id="mess" rows=5 cols=100 name="services" placeholder="Type your Services here "></textarea>
              </div>
              <div>
                <label  class="ff">Enter Your Working Experience:</label><br/>
                <textarea id="mess" rows=5 cols=100 name="experience" placeholder="Type your Experience here "></textarea>
              </div>

              <div>
                <label  class="ff">For How much Experience you have?</label><br/>
                <input type="number" size="10" name="yearNo" class="doc" />
                <select name="years" class="doc">
                     <option>Years</option>
                     <option>Months</option>
                </select> 
              </div>

              <div class="clinic">
              <br>
                     <h2>Organization Address</h2>
                     <div>
                            <label  class="ff">Name of your Working Organization:</label>
                            <input type="text"  name="organization" class="doc" /><br/><br>
                            <label  class="ff">Location:</label>
                            <input type="text" size="12" name="location" class="doc" />
                            <label  class="ff">City:</label>
                            <input type="text" size="10" name="city" class="doc" />
                     </div>
              <br>
              </div>
              
              <div class="clinic">
              <br>
                     <h2>In-Clinic Appointement</h2>
                     <div>
                            <br>
                            <img src="/MyLaravel/Laravel/public/images/video.png" class="image" /> <br>
                            <label class="ff">Select Your Available Days:</label><br>
                            <span class="check">Monday</span>
                            <input type="checkbox" name="days[]" value="Monday"/> <br>
                            <span class="check">Tuesday</span>
                            <input type="checkbox"  name="days[]" value="Tuesday"/> <br>
                            <span class="check1">Wednesday</span>
                            <input type="checkbox"  name="days[]" value="Wednesday"/><br> 
                            <span class="check2">Thursday</span>
                            <input type="checkbox"  name="days[]" value="Thursday"/> <br>
                            <span class="check3">Friday</span>
                            <input type="checkbox" name="days[]" value="Friday"/> <br>
                            <span class="check4">Saturday</span>
                            <input type="checkbox" name="days[]" value="Saturday"/><br> 
                            <span class="check5">Sunday</span>
                            <input type="checkbox"  name="days[]" value="Sunday"/> <br><br>

                            <label class="ff">Select Your Available Timings:</label><br>
                            <span class="ff">From:</span><input type="time" size="10" name="from" class="doc" />
                            <span class="ff">To:</span><input type="time" size="10" name="to" class="doc" /><br>
                            <br>
                            <label class="ff">Select Your Appointement Duration(min):</label>
                            <select  name="duration"  id="disease" class="doc">
                                   <option>10</option><option>15</option><option>20</option><option>25</option><option>30</option>
                            </select>
                               
                     </div>
 
                     <br>
                     <div>
                            <label class="ff">Enter Your Fees:</label>
                            <input type="text" size="10" name="fees" class="doc" />
                            
                     </div>

              <br><br>
              </div>
              <div class="video">
              <br>
                     <h2>Video Consultation</h2>
                     <div>
                            <br>
                            <img src="/MyLaravel/Laravel/public/images/clinic.png" class="image" /> <br>
                            <label class="ff">Select Your Available Days:</label><br>
                            <span class="check">Monday</span>
                            <input type="checkbox" name="Vdays[]" value="Monday"/> <br>
                            <span class="check">Tuesday</span>
                            <input type="checkbox"  name="Vdays[]" value="Tuesday"/> <br>
                            <span class="check1">Wednesday</span>
                            <input type="checkbox"  name="Vdays[]" value="Wednesday"/><br> 
                            <span class="check2">Thursday</span>
                            <input type="checkbox"  name="Vdays[]" value="Thursday"/> <br>
                            <span class="check3">Friday</span>
                            <input type="checkbox" name="Vdays[]" value="Friday"/> <br>
                            <span class="check4">Saturday</span>
                            <input type="checkbox" name="Vdays[]" value="Saturday"/><br> 
                            <span class="check5">Sunday</span>
                            <input type="checkbox"  name="Vdays[]" value="Sunday"/> <br><br>

                            <label class="ff">Select Your Available Timings:</label><br>
                            <span class="ff">From:</span><input type="time" size="10" name="Vfrom" class="doc" />
                            <span class="ff">To:</span><input type="time" size="10" name="Vto" class="doc" /><br>
                            <br>
                            <label class="ff">Select Your Appointement Duration(min):</label>
                            <select  name="Vduration"  id="disease" class="doc">
                                   <option>10</option><option>15</option><option>20</option><option>25</option><option>30</option>
                            </select>                             
                     </div>
                     <br>
                     <div>
                            <br>
                            <label class="ff">Enter Your Fees:</label>
                            <input type="text" size="10" name="Vfees" class="doc" />
                            
                     </div>

              <br>
              </div>
              
              
              <br/>
              <br/>
              <button class="btn btn-outline-primary"  id="d_btnn" name="txtbutton" ><a >Submit</a></button>
              </form>
            

       


    </div>
</div>       

<script>
var loadFile = function(event) {
	var image = document.getElementById('output');
	image.src = URL.createObjectURL(event.target.files[0]);
};
</script>

@endsection