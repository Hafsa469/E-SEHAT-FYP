@extends('layout.sehat')
@section('title','Doctor Form')
@section('contents')

{{csrf_field()}}


<div class="d_wrapper">
    <div class="mdp_form-wrapper">
                
                <br>
                
              <form>
              {{csrf_field()}}
              <!--<p><img src="/MyLaravel/Laravel/public/images/doctor.png" id="doutput" width="200" /></p>-->
              <!-- Example single danger button -->
              <div class="btn-group dropright">
              <button type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Fee Range</button>
                     <ul class="dropdown-menu">
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/0'>0-1000</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/1000'>1000-2000</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/2000'>2000-3000</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/3000'>3000-4000</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/4000'>4000-5000</a></li>
                     </ul>
              </div>
              
              <div class="dropdown  ">
                     <button class="btn btn-danger dropdown-toggle" type="button" data-toggle="dropdown">All Pakistan<span class="caret"></span></button>
                     <ul class="dropdown-menu " style="height:200px; overflow-y:scroll">
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/0'>All Pakistan</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Islamabad'>Islamabad</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Karachi'>Karachi</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Peshawar'>Peshawar</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Sargodha'>Sargodha</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Faisalabad'>Faisalabad</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Multan'>Multan</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Lahore'>Lahore</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Quetta'>Quetta</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Gujranwala'>Gujranwala</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Gujrat'>Gujrat</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Bahawalpur'>Bahawalpur</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Charsadda'>Charsadda</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Hyderabad'>Hyderabad</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Jehlum'>Jehlum</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Kasor'>Kasor</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Kohat'>Kohat</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Layyah'>Layyah</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Sahiwal'>Sahiwal</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Sheikupura'>Sheikupura</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Sialkot'>Sialkot</a></li>
                            <div class="dropdown-divider"></div>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/3000/clinic'>Others</a></li>
                     </ul>
              </div>
              <div class="dropdown">
                     <button class="btn btn-danger dropdown-toggle" type="button" data-toggle="dropdown">Specialsts<span class="caret"></span></button>
                     <ul class="dropdown-menu " style="height:200px; overflow-y:scroll">
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/0'>All Specialists</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Dermatologists'>Dermatologists</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Gynecologists'>Gynecologists</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Child Specialists'>Child Specialists</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Neurologist'>Neurologists</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Psychiatrist'>Psychiatrist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/General Physician'>General Physician</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Cardiologist'>Cardiologist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Eye Specialists'>Eye Specialists</a></li>
                            <div class="dropdown-divider"></div>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/3000/clinic'>Others</a></li>

                     </ul>
              </div>
              @if(!empty($success))
                <div class="alert alert-success" id="cerrors"> 
                {{ $success}}
                </div>
              @endif
              @foreach($doctor as $key => $doctor)
              <div class="clinic">
              <br><br>
              <div>
                     <p><img src="/MyLaravel/Laravel/storage/uploads{{$doctor['Image']}}" id="output" width="200" /></p>
              </div>
              <div style=" position:relative; left:250px; bottom:200px;">
                     <span class="red1"><u>{{$doctor["name"]}}</u></span><br>
                     <span class="red2">{{$doctor["designation"]}}<span class="red2">,<span><span class="red2">{{$doctor["speciality"]}}</span></span><br>
                     <span class="red1">{{$doctor["Organization"]}}<span class="red1">,<span><span class="red1">{{$doctor["Location"]}}</span></span><br>
                     <span class="red1">{{$doctor["City"]}}<span class="red1">, Experience<span><span class="red1">{{$doctor["Experience_Time"]}}</span></span>  
              </div>
              <div style=" position:relative; left:390px; bottom:350px;">
              <button class="btn btn-outline-primary"  id="e_btnn" name="txtbutton" ><a href='/MyLaravel/Laravel/public/E-SEHAT/{{$key}}/clinic'>Book In-Clinic Appointment</a></button>
              <button class="btn btn-outline-primary"  id="e_btnn" name="txtbutton" ><a href='/MyLaravel/Laravel/public/E-SEHAT/{{$key}}/video'>Book Video Consultation</a></button>
              <button class="btn btn-outline-primary"  id="e_btnn" name="txtbutton" ><a href='/MyLaravel/Laravel/public/E-SEHAT/{{$key}}/viewprofile'>View Profile</a></button>
              </div>
              <p class="fff" style=" position:relative; left:2px; bottom:240px; right:25px;"><span class="red2" style="font-size:20px;">Message: </span>{{$doctor["message"]}}</p>
             
   
              </div>
             
              @endforeach
              </form>
              

            

       


    </div>
</div>       




@endsection