@extends('layout.doctor')
@section('title','Login Form')
@section('contents')




<div class="wrap">
       <div class="ddform-wrapper">
    
<form action="" method="POST">
{{csrf_field()}}
    <div>
    <label id="click">Complete Your Profile First:</label><br/>
    </div>
    <br/>
    <button class="btn btn-outline-primary"  id="ebtn" name="txtbutton" ><a href="{{url('/E-SEHAT/doctorProfile')}}">Profile Settings</a></button>
    <br/>

    <br/>

</form>



</div>
</div>



@endsection