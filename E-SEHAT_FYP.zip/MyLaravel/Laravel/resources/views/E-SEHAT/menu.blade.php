@extends('layout.sehat')
@section('title','Main Menu')
@section('contents')



{{csrf_field()}}


<img src="/MyLaravel/Laravel/public/images/image6.jpg" class="img" />
<p id="para">We Care</p>
<p id="para1">For Your Health</p>
<p id="para2">Our Team of Doctors are specialized in Various Disciplines to make <br>sure you get the Best Treatment</p>

@if(!(session()->has('email')))
<button class="btn btn-outline-primary"  id="sbtn" name="txtbutton" ><a href="{{url('/E-SEHAT/UserRegister')}}" >Signup Now</a></button>
<button class="btn btn-outline-primary"  id="lbtn" name="txtbutton" ><a href="{{url('/E-SEHAT/login')}}">Login</a></button>
@endif 

@endsection










