@extends('layout.sehat')
@section('title','Doctor Form')
@section('contents')

{{csrf_field()}}


<div class="d_wrapper">
    <div class="mdp_form-wrapper">
            
            <br>
             <form action="{{url('/select')}}" method="POST">
             {{csrf_field()}}
             @if (count($errors) > 0)
                <div class = "alert alert-danger" id="cerrors">
                    <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                    </ul>
                </div>
            @endif
            @if(!empty($success))
                <div class="alert alert-success" id="cerrors"> 
                {{ $success}}
                </div>
            @endif 
             <div style="background-color:darkblue; color:white; height:450px;">
            <p id="pstyle">E-SEHAT: Find, Book and Consult Doctors</p>
            <p id="mstyle"> How can we help you today?</p>
                <div style="margin-left:100px;">  
                    <input type="text" name="city" size=6 style="color:black;" pattern="[A-Z][a-z]*" title="Must Capitalize Your First Letter like Lahore" placeholder="Enter City"/><input type="text" size="35" name="search" style="color:black;" pattern="[A-Z][a-z]*" title="Must Capitalize Your First Letter like Neurologist" placeholder="Search for Specialites and Diseases" />
                    <button class="btn btn-outline-primary"  id="btnn" name="txtbutton" style="margin-left:360px;" ><a >Submit</a></button>
                </div>
                <br/><br>
                <p><img src="/MyLaravel/Laravel/public/images/doctor.png" id="doutput" width="200" /></p>
            </div>
             </form>   

            <form>
            {{csrf_field()}}
              <!-- Example single danger button -->
              <div class="dropdown" style="margin-left: 60px; margin-top:25px;">
              <button type="button" class="btn btn-secondary btn-lg dropdown-toggle" id="write" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Fee Range</button>
                     <ul class="dropdown-menu">
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/0/fee'>0-1000</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/1000/fee'>1000-2000</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/2000/fee'>2000-3000</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/3000/fee'>3000-4000</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/4000/fee'>4000-5000</a></li>
                     </ul>
              </div>
              
              <div class="dropdown " style="position:relative; left: 250px; bottom:45px;">
                     <button class="btn btn-danger btn-lg dropdown-toggle" type="button" id="write" data-toggle="dropdown">Find Doctor By City</button>
                     <ul class="dropdown-menu " style="height:200px; overflow-y:scroll">
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/0/city'>All Pakistan</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Islamabad/city'>Islamabad</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Karachi/city'>Karachi</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Peshawar/city'>Peshawar</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Sargodha/city'>Sargodha</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Rawalpindi/city'>Rawalpindi</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Bahawalnagr/city'>Bahawalnagr</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Faisalabad/city'>Faisalabad</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Multan/city'>Multan</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Lahore/city'>Lahore</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Quetta/city'>Quetta</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Gujranwala/city'>Gujranwala</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Gujrat/city'>Gujrat</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Bahawalpur/city'>Bahawalpur</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Charsadda/city'>Charsadda</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Hyderabad/city'>Hyderabad</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Jehlum/city'>Jehlum</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Jamshoro/city'>Jamshoro</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Jeddah/city'>Jeddah</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Sahiwal/city'>Sahiwal</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Mirpur/city'>Mirpur</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Kasor/city'>Kasor</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Kohat/city'>Kohat</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Layyah/city'>Layyah</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Larkana/city'>Larkana</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Sahiwal/city'>Sahiwal</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Sheikupura/city'>Sheikupura</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Sialkot/city'>Sialkot</a></li>
                            <div class="dropdown-divider"></div>
                            <li>Others:
                            <input  size="5" height="15px" type="text" id="wage"  placeholder="Enter City" pattern="[A-Z][a-z]*{1,}" name="search"/>
                            <button class="btn btn-outline-warning" id="ico" onclick="find();"><a href="/MyLaravel/Laravel/public/E-SEHAT/" onclick="location.href=this.href+ document.getElementById('wage').value+'/city';return false;" id="link"><i class="fa fa-search" ></i></a></button>
                            <!--<button class="btn btn-outline-warning" id="ico"><a href="/MyLaravel/Laravel/public/E-SEHAT/" onclick="find();" id="link"><i class="fa fa-search" ></i></a></button>-->
                            </li>
                     </ul>
              </div>
              <div class="dropdown" style="position:relative; left: 520px; bottom:90px;">
                     <button class="btn btn-primary btn-lg dropdown-toggle" type="button" data-toggle="dropdown" id="write">All Specialists</button>
                     <ul class="dropdown-menu " style="height:200px; overflow-y:scroll">
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/0/specilist'>All Specialists</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Andrologist/specilist'>Andrologist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Anesthetist/specilist'>Anesthetist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Audiologist/specilist'>Audiologist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Acupuncture/specilist'>Acupuncture</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Allergy Specialist/specilist'>Allergy Specialist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Bariatric/specilist'>Bariatric / Weight Loss Surgeon</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Child Specialist/specilist'>Child Specialist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Cardiologist/specilist'>Cardiologist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Cancer Specialist/specilist'>Cancer Specialist / Oncologist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Cancer Surgeon/specilist'>Cancer Surgeon</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Cosmatic Surgeon/specilist'>Cosmetic Surgeon</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Cardiac Surgeon/specilist'>Cardiac Surgeon</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Dermatologist/specilist'>Dermatologist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Dietitian/specilist'>Dietitian/Nutritionist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Dentist/specilist'>Dentist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Diabetologist/specilist'>Diabetologist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Endocrinologist/specilist'>Endocrinologist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Endourologist/specilist'>Endourologist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Eye Surgeon/specilist'>Eye Surgeon</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Eye Specialist/specilist'>Eye Specialist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Ent Surgeon/specilist'>Ent Surgeon</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Family Medicine/specilist'>Family Medicine</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Gynecologist/specilist'>Gynecologist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Geneticist/specilist'>Geneticist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Gastroenterologist/specilist'>Gastroenterologist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/General Surgeon/specilist'>General Surgeon</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/General Practitioner/specilist'>General Practitioner</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/General Physician/specilist'>General Physician</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Hematologist/specilist'>Hematologist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Homeopath/specilist'>Homeopath</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHATHijama Specialist/specilist'>Hijama Specialist / Oncologist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Haemoncologist/specilist'>Haemoncologist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Immunologist/specilist'>Immunologist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Internal Medicine/specilist'>Internal Medicine</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Lung Surgeon/specilist'>Lung Surgeon</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Liver Specialist/specilist'>Liver Specialist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Neurologist/specilist'>Neurologist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Optometrist/specilist'>Optometrist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Orthodontist/specilist'>Orthodontist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Physiotherapist/specilist'>Physiotherapist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Plastic Surgeon/specilist'>Plastic Surgeon</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Pediatrician/specilist'>Pediatrician</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Psychiatrist/specilist'>Psychiatrist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Psychologist/specilist'>Physcologist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Pathologist/specilist'>Pathologist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Pharmacist/specilist'>Pharmacist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Pulmnologist/specilist'>Pulmnologist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Radiologist/specilist'>Radiologist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Rheumatologist/specilist'>Rheumatologist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Rehabilitation Medicine/specilist'>Rehabilitation Medicine</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Radiation Oncologist/specilist'>Radiation Oncologist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Sexologist/specilist'>Sexologist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Sonologist/specilist'>Sonologist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Speech Theraphist/specilist'>Speech Theraphist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Spinal Surgeon/specilist'>Spinal Surgeon</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Urologist/specilist'>Urologist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Urological Oncologist/specilist'>Urological Oncologist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Vaccine Specialist/specilist'>Vaccine Specialist</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Vascular Surgeon/specilist'>Vascular Surgeon</a></li>
                            <div class="dropdown-divider"></div>
                            <li>Others:
                            <input  size="6" height="15px" type="text" id="wag"  pattern="[A-Z][a-z]*{1,}" placeholder="Enter Speciality" name="search" />
                            <button class="btn btn-outline-warning" id="ico" onclick="findSp();"><a href="/MyLaravel/Laravel/public/E-SEHAT/" onclick="location.href=this.href+ document.getElementById('wag').value+'/specilist';return false;" ><i class="fa fa-search" ></i></a></button>
                            <!--<button class="btn btn-outline-warning" id="ico"><a onclick="findSp();" id="link"><i class="fa fa-search" ></i></a></button>-->
                            </li>
                     </ul>
              </div>
              <div class="dropdown" style="position:relative; left: 750px; bottom:135px;">
                     <button class="btn btn-warning btn-lg dropdown-toggle" type="button" data-toggle="dropdown" id="write">Find Doctor By Disease</button>
                     <ul class="dropdown-menu " style="height:200px; overflow-y:scroll">
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/0/disease'>All Diseases</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Drug Reaction/disease'>Drug Reaction</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Fungal infection/disease'>Fungal infection</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Malaria/disease'>Malaria</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Allergy/disease'>Allergy</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Hypothyroidism/disease'>Hypothyroidism</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Psoriasis/disease'>Psoriasis</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Chronic cholestasis/disease'>Chronic cholestasis</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/GERD/disease'>GERD</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Hepatitis/disease'>Hepatitis</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Osteoarthristis/disease'>Osteoarthristis</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Hypoglycemia/disease'>Hypoglycemia</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Impetigo/disease'>Impetigo</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Diabetes/disease'>Diabetes</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Acne/disease'>Acne</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Hypertension/disease'>Hypertension</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Peptic ulcer disease/disease'>Peptic ulcer disease</a></li>
                            <li><a href='/MyLaravel/Laravel/public/E-SEHAT/Common Cold/disease'>Common Cold</a></li>
                     
                     </ul>
              </div>
             
              @foreach($doctor as $key => $doctor)
              <div class="clinic" style="position:relative; bottom:90px;">
              <br><br>
              <div>
                     <p><img src="/MyLaravel/Laravel/storage/uploads{{$doctor['Image']}}" id="output" width="200" /></p>
              </div>
              <div style=" position:relative; left:250px; bottom:200px;">
                     <span class="red1"><u>{{$doctor["name"]}}</u></span><br>
                     <span class="red2">{{$doctor["designation"]}}<span class="red2">,<span><span class="red2">{{$doctor["speciality"]}}</span></span><br>
                     <span class="red1">{{$doctor["Organization"]}}<span class="red1">,<span><span class="red1">{{$doctor["Location"]}}</span></span><br>
                     <span class="red1">{{$doctor["City"]}}<span class="red1">, Experience<span><span class="red1">{{$doctor["Experience_Time"]}}</span></span>  
                     <br><span class="red2">Fees: {{$doctor["Fees"]}}</span>
              </div>
              <div style=" position:relative; left:390px; bottom:350px;">
              <button class="btn btn-outline-primary"  id="e_btnn" name="txtbutton" ><a href='/MyLaravel/Laravel/public/E-SEHAT/{{$doctor["id"]}}/clinic'>Book In-Clinic Appointment</a></button>
              <button class="btn btn-outline-primary"  id="e_btnn" name="txtbutton" ><a href='/MyLaravel/Laravel/public/E-SEHAT/{{$doctor["id"]}}/video'>Book Video Consultation</a></button>
              <button class="btn btn-outline-primary"  id="e_btnn" name="txtbutton" ><a href='/MyLaravel/Laravel/public/E-SEHAT/{{$doctor["id"]}}/viewDocprofile'>View Profile</a></button>
              </div>
              <p class="fff" style=" position:relative; left:2px; bottom:240px; right:25px;"><span class="red2" style="font-size:20px;">Message: </span>{{$doctor["message"]}}</p>
             
   
              </div>
             
              @endforeach
              </form>
              

            

       


    </div>
</div>       

<script>
/*var wage = document.getElementById("wage");
wage.addEventListener("keydown", function (e) {
    if (e.keyCode === 13) {
        validate(e);
    }
});
*/

function findSp()
{
       if(document.getElementById('wag').value == '')
       {
              //document.getElementById('wag').value="0";
              alert("Must Enter Value!");
              history.go(-1);
       }
       
}
function find()
{
       if(document.getElementById('wage').value == '')
       {
              //document.getElementById('wage').value="0";
              alert("Must Enter Value!");
              history.go(-1);
       }
}
</script>


@endsection