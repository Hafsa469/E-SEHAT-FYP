<!DOCTYPE html>
<html>
<head>
    
    <title>App Name - @yield('title')</title>
    <link rel="stylesheet" type="text/css" href="{{asset('css/app.css')}}">
    
</head>
<body>
{{-- 
<img src="{{asset('images/image.jpg')}}"/>--}}
    <h1>Welcome To HomePage!</h1>
    @yield('contents')
    <p><small>Copyrights&copy; {{date('Y')}}</small></p>
    <script src="{{asset('java/app.js')}}"></script>
</body>
</html>